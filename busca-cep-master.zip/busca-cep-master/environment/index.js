'use strict';

const config = {
    apiViaCep: {
        url: 'https://viacep.com.br'
    }
};

module.exports = config;